# Visendi Multi-Agent AI Demo

This project is a small, focused demo of a **multi-agent AI workflow** for hardware / supply chain planning, inspired by the kind of systems Visendi builds.

It is intentionally simple, but it shows that you can:

- Design a multi-agent architecture
- Orchestrate several AI "agents" with clear responsibilities
- Expose the workflow through a clean API
- Containerise the service with Docker

## Concept

The API exposes a single main endpoint:

`POST /api/scenario`

with a JSON body like:

```json
{
  "productDescription": "Battery-powered environmental sensor for indoor warehouses",
  "targetVolumePerMonth": 5000,
  "targetMarkets": ["Germany", "Netherlands", "Sweden"],
  "constraints": "Must work in cold storage conditions and be easy to mount."
}
```

The request flows through three simple agents:

1. **Planner Agent** – produces a high-level operations and rollout plan.
2. **Logistics Agent** – proposes a logistics strategy based on the plan and target markets.
3. **Cost Agent** – provides a rough cost narrative and highlights the main cost drivers.

Each agent uses the shared `callLLM` helper, which can either call the OpenAI API (if an `OPENAI_API_KEY` is configured) or return mocked responses for local testing.

The orchestrator combines all three agents into a single result and returns it as JSON.

## Tech Stack

- **TypeScript**
- **Node.js + Express**
- **OpenAI Node client** (or mocked responses)
- **Zod** for input validation
- **Docker** for containerization

This aligns well with Visendi's stack (Python / Golang / TypeScript / React / Node.js / Docker).

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

Copy `.env.example` to `.env` and add your OpenAI API key:

```bash
cp .env.example .env
```

Edit `.env`:

```env
OPENAI_API_KEY=sk-...
PORT=3000
```

If you do **not** set an API key, the service will still run, but responses will be clearly marked as mocked.

### 3. Run in development mode

```bash
npm run dev
```

Then, test the API with curl or a tool like Postman / Insomnia:

```bash
curl -X POST http://localhost:3000/api/scenario   -H "Content-Type: application/json"   -d '{
    "productDescription": "Battery-powered environmental sensor for indoor warehouses",
    "targetVolumePerMonth": 5000,
    "targetMarkets": ["Germany", "Netherlands", "Sweden"],
    "constraints": "Must work in cold storage conditions and be easy to mount."
  }'
```

### 4. Build and run with Docker

```bash
docker build -t visendi-multi-agent-demo .
docker run --rm -p 3000:3000 --env-file .env visendi-multi-agent-demo
```

## Possible Extensions

If you want to grow this into a richer demo, here are some ideas:

- Add a **simple React front end** that lets users enter the scenario interactively.
- Add a **"simulation mode"** where different parameter combinations (volumes, markets) are compared.
- Persist scenarios in a database (e.g. Postgres) to show basic stateful behaviour.
- Add more agents (e.g. Risk Agent, Sustainability Agent) to demonstrate more complex coordination patterns.

## How This Relates to Visendi

This mini-project focuses on:

- Multi-agent orchestration around a real-world physical product scenario
- Pragmatic engineering choices (simple API surface, clear code structure)
- Production-minded details (input validation, dotenv, Dockerfile)

It demonstrates that you can **design and implement an AI-enabled backend feature** that fits nicely into a product aimed at manufacturing / logistics / hardware design workflows.
