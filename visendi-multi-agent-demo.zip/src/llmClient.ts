import OpenAI from "openai";

const apiKey = process.env.OPENAI_API_KEY;

if (!apiKey) {
  console.warn("[llmClient] No OPENAI_API_KEY set. The server will still run, but responses will be mocked.");
}

const client = apiKey ? new OpenAI({ apiKey }) : null;

export async function callLLM(systemPrompt: string, userPrompt: string): Promise<string> {
  if (!client) {
    // Fallback mock for environments without an API key.
    return `MOCKED RESPONSE: (system='${systemPrompt.slice(0, 40)}...', user='${userPrompt.slice(0, 40)}...')`;
  }

  const completion = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ],
    temperature: 0.4
  });

  const choice = completion.choices[0]?.message?.content;
  return choice ?? "";
}
