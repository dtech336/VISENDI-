import { callLLM } from "../llmClient";

export interface PlanningInput {
  productDescription: string;
  targetVolumePerMonth: number;
  targetMarkets: string[];
  constraints?: string;
}

export interface PlanningOutput {
  highLevelPlan: string;
  keyPhases: string[];
}

export async function plannerAgent(input: PlanningInput): Promise<PlanningOutput> {
  const systemPrompt = "You are a senior hardware operations planner. Break down product development, manufacturing and rollout into clear phases.";
  const userPrompt = `We want to build and ship a hardware product.
Product description: ${input.productDescription}
Target volume per month: ${input.targetVolumePerMonth}
Target markets: ${input.targetMarkets.join(", ")}
Constraints: ${input.constraints ?? "none"}

1) Give a short high-level plan (3-4 sentences).
2) List 4-7 key phases as bullet points.`;

  const text = await callLLM(systemPrompt, userPrompt);

  // For simplicity, we just split lines: first paragraph + bullet lines.
  const lines = text.split("\n").map(l => l.trim()).filter(Boolean);
  const highLevelPlan = lines[0] ?? text;
  const keyPhases = lines.slice(1);

  return { highLevelPlan, keyPhases };
}
