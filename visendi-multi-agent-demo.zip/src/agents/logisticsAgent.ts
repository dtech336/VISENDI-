import { callLLM } from "../llmClient";
import { PlanningOutput } from "./plannerAgent";

export interface LogisticsPlan {
  summary: string;
  recommendations: string[];
}

export async function logisticsAgent(plan: PlanningOutput, targetMarkets: string[]): Promise<LogisticsPlan> {
  const systemPrompt = "You are a supply chain and logistics planner. You design pragmatic logistics strategies for manufacturing and distribution.";
  const userPrompt = `We have this high-level plan:

${plan.highLevelPlan}

Key phases:
${plan.keyPhases.join("\n")}

Target markets: ${targetMarkets.join(", ")}

Give:
1) A short logistics strategy summary.
2) 3-5 bullet recommendations (incoterms, warehouse locations, shipping modes, main risks).`;

  const text = await callLLM(systemPrompt, userPrompt);
  const lines = text.split("\n").map(l => l.trim()).filter(Boolean);
  const summary = lines[0] ?? text;
  const recommendations = lines.slice(1);
  return { summary, recommendations };
}
