import { callLLM } from "../llmClient";
import { PlanningInput } from "./plannerAgent";
import { LogisticsPlan } from "./logisticsAgent";

export interface CostEstimate {
  narrative: string;
  roughMonthlyCostRange: string;
  mainCostDrivers: string[];
}

export async function costAgent(input: PlanningInput, logistics: LogisticsPlan): Promise<CostEstimate> {
  const systemPrompt = "You are an operations cost analyst. You estimate rough cost ranges and highlight the main cost drivers.";
  const userPrompt = `We are planning a hardware product.

Product description: ${input.productDescription}
Target volume per month: ${input.targetVolumePerMonth}
Target markets: ${input.targetMarkets.join(", ")}

Logistics plan summary:
${logistics.summary}

Logistics recommendations:
${logistics.recommendations.join("\n")}

1) Give a short narrative cost overview.
2) Provide a rough monthly cost range as a single line like 'EUR X - Y per month'.
3) List 3-5 main cost drivers as bullet points.`;

  const text = await callLLM(systemPrompt, userPrompt);
  const lines = text.split("\n").map(l => l.trim()).filter(Boolean);

  let narrative = "";
  let roughMonthlyCostRange = "";
  const mainCostDrivers: string[] = [];

  for (const line of lines) {
    if (!narrative) {
      narrative = line;
    } else if (!roughMonthlyCostRange && /EUR|USD|SEK/i.test(line)) {
      roughMonthlyCostRange = line;
    } else {
      mainCostDrivers.push(line);
    }
  }

  if (!roughMonthlyCostRange) {
    roughMonthlyCostRange = "N/A (mocked or not specified by the model)";
  }

  return { narrative, roughMonthlyCostRange, mainCostDrivers };
}
