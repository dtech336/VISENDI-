import "dotenv/config";
import express from "express";
import { z } from "zod";
import { runMultiAgentScenario } from "./orchestrator";

const app = express();
app.use(express.json());

const planningInputSchema = z.object({
  productDescription: z.string().min(10),
  targetVolumePerMonth: z.number().int().positive(),
  targetMarkets: z.array(z.string()).min(1),
  constraints: z.string().optional()
});

app.get("/", (_req, res) => {
  res.json({
    message: "Visendi-style multi-agent AI demo is running.",
    endpoints: ["/api/scenario"]
  });
});

app.post("/api/scenario", async (req, res) => {
  const parseResult = planningInputSchema.safeParse(req.body);
  if (!parseResult.success) {
    return res.status(400).json({ error: "Invalid input", details: parseResult.error.issues });
  }

  try {
    const result = await runMultiAgentScenario(parseResult.data);
    res.json(result);
  } catch (err: any) {
    console.error("[/api/scenario] Error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

const port = process.env.PORT ? Number(process.env.PORT) : 3000;
app.listen(port, () => {
  console.log(`🚀 Multi-agent demo API listening on http://localhost:${port}`);
});
