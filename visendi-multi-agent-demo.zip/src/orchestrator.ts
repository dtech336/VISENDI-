import { plannerAgent, PlanningInput } from "./agents/plannerAgent";
import { logisticsAgent } from "./agents/logisticsAgent";
import { costAgent } from "./agents/costAgent";

export interface OrchestratorResult {
  planning: Awaited<ReturnType<typeof plannerAgent>>;
  logistics: Awaited<ReturnType<typeof logisticsAgent>>;
  cost: Awaited<ReturnType<typeof costAgent>>;
}

export async function runMultiAgentScenario(input: PlanningInput): Promise<OrchestratorResult> {
  const planning = await plannerAgent(input);
  const logistics = await logisticsAgent(planning, input.targetMarkets);
  const cost = await costAgent(input, logistics);

  return { planning, logistics, cost };
}
